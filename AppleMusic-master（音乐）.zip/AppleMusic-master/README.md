# 可以播放音乐的微信小程序版 Apple Music
微信小程序，仿Apple Music  
搜索页可以播放单曲了，因资源问题部分搜索结果不能播放  
![截图](https://github.com/Sioxas/AppleMusic/raw/master/srceenshot/sp160929_125258.png "首页")  

![截图](https://github.com/Sioxas/AppleMusic/raw/master/srceenshot/sp160929_125930.png "actionsheet")  

![截图](https://github.com/Sioxas/AppleMusic/raw/master/srceenshot/sp160929_125231.png "搜索页面")
